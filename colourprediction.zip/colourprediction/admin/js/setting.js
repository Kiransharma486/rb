		CKEDITOR.replace( 'question',
				{ 	   
				fontSize_sizes : "8/80%;9/90%;10/100%;12/120%;14/135%;16/160%;18/180%;20/200%;24/240%;26/260%;28/280%;36/360%;48/480%;72/650%;",
					toolbar :
					[
			['Source','Undo','Redo','Table'],
			['Bold', 'Italic','Underline','JustifyLeft','-','JustifyCenter','JustifyRight','-','JustifyBlock','NumberedList','BulletedList'],
			['SImage'],['Image'],

				['Styles','Format','FontSize' ],['TextColor'],
				['EqnEditor'],['ckeditor_wiris_formulaEditor', 'ckeditor_wiris_formulaEditorChemistry' , 'ckeditor_wiris_CAS'],
					],
		resize: "none",
        height: "120px",
		resize_enabled:false,
		toolbarCanCollapse : false
	
		} );
		
		
			
		CKEDITOR.replace( 'opt1',
				{ 	   
				fontSize_sizes : "8/80%;9/90%;10/100%;12/120%;14/135%;16/160%;18/180%;20/200%;24/240%;26/260%;28/280%;36/360%;48/480%;72/650%;",
					toolbar :
					[
			['Source','Undo','Redo','Table'],
			['Bold', 'Italic','Underline','JustifyLeft','-','JustifyCenter','JustifyRight','-','JustifyBlock','NumberedList','BulletedList'],
			['SImage'],['Image'],

				['Styles','Format','FontSize' ],['TextColor'],
				['EqnEditor'],['ckeditor_wiris_formulaEditor', 'ckeditor_wiris_formulaEditorChemistry' , 'ckeditor_wiris_CAS'],
					],
		resize: "none",
        height: "120px",
		resize_enabled:false,
		toolbarCanCollapse : false
	
		} );
		
		
			
		CKEDITOR.replace( 'opt2',
				{ 	   
				fontSize_sizes : "8/80%;9/90%;10/100%;12/120%;14/135%;16/160%;18/180%;20/200%;24/240%;26/260%;28/280%;36/360%;48/480%;72/650%;",
					toolbar :
					[
			['Source','Undo','Redo','Table'],
			['Bold', 'Italic','Underline','JustifyLeft','-','JustifyCenter','JustifyRight','-','JustifyBlock','NumberedList','BulletedList'],
			['SImage'],['Image'],

				['Styles','Format','FontSize' ],['TextColor'],
				['EqnEditor'],['ckeditor_wiris_formulaEditor', 'ckeditor_wiris_formulaEditorChemistry' , 'ckeditor_wiris_CAS'],
					],
		resize: "none",
        height: "120px",
		resize_enabled:false,
		toolbarCanCollapse : false
	
		} );
		
		
			
		CKEDITOR.replace( 'opt3',
				{ 	   
				fontSize_sizes : "8/80%;9/90%;10/100%;12/120%;14/135%;16/160%;18/180%;20/200%;24/240%;26/260%;28/280%;36/360%;48/480%;72/650%;",
					toolbar :
					[
		['Source','Undo','Redo','Table'],
		['Bold', 'Italic','Underline','JustifyLeft','-','JustifyCenter','JustifyRight','-','JustifyBlock','NumberedList','BulletedList'],
		['SImage'],['Image'],

				['Styles','Format','FontSize' ],['TextColor'],
				['EqnEditor'],['ckeditor_wiris_formulaEditor', 'ckeditor_wiris_formulaEditorChemistry' , 'ckeditor_wiris_CAS'],
					],
		resize: "none",
        height: "120px",
		resize_enabled:false,
		toolbarCanCollapse : false
	
		} );
		
		
			
		CKEDITOR.replace( 'opt4',
				{ 	   
				fontSize_sizes : "8/80%;9/90%;10/100%;12/120%;14/135%;16/160%;18/180%;20/200%;24/240%;26/260%;28/280%;36/360%;48/480%;72/650%;",
					toolbar :
					[
			['Source','Undo','Redo','Table'],
			['Bold', 'Italic','Underline','JustifyLeft','-','JustifyCenter','JustifyRight','-','JustifyBlock','NumberedList','BulletedList'],
			['SImage'],['Image'],

				['Styles','Format','FontSize' ],['TextColor'],
				['EqnEditor'],['ckeditor_wiris_formulaEditor', 'ckeditor_wiris_formulaEditorChemistry' , 'ckeditor_wiris_CAS'],
					],
		resize: "none",
        height: "120px",
		resize_enabled:false,
		toolbarCanCollapse : false
	
		} );
		
		
			
